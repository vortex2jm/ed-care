#ifndef validation_h
#define validation_h

int ValidateArg(int argc);

int NumberOfReadings(char ** argv);

#endif