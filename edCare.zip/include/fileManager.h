#ifndef file_manager_h
#define file_manager_h
#include <math.h>

char * FileFirstLine(char * way);

double Distance(long int * coordinates1, long int * coordinates2);

#endif