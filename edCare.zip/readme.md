# Instructions
 - Put .h files on "./include" directory
 - Leave "main.c" file on root directory
 - Put another .c files on "./src" directory